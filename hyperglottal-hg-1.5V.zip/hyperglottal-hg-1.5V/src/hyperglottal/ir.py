from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class Decl:
    name: str
    kind: str
    type: str | None = None
    body: str | None = None

@dataclass
class Module:
    name: str
    decls: List[Decl] = field(default_factory=list)
    policies: Dict[str, Any] = field(default_factory=dict)
