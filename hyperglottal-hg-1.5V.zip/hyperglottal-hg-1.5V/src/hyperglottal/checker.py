def typecheck(module_text: str) -> bool:
    # Minimal stub: ensures "def" appears and parentheses seem balanced.
    if "def " not in module_text:
        return False
    opens = module_text.count("(")
    closes = module_text.count(")")
    return opens == closes
