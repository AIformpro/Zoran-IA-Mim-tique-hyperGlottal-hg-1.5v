# stdlib-only CLI mock for HyperGlottal
from __future__ import annotations
import argparse, sys, json, os, hashlib, pathlib, datetime, textwrap

VERSION = "1.5.0"
CODENAME = "1.5V"

BANNER = f"HyperGlottal CLI v{VERSION} ({CODENAME}) — stdlib-only subset M0"

def cmd_version(args):
    print(BANNER)

def cmd_new(args):
    path = pathlib.Path(args.path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text('-- new HyperGlottal file\n' +
                        'def add(a:Int,b:Int)=a+b\n' +
                        'def main()=print("ok", add(1,41))\n')
        print(f"Created {path}")
    else:
        print(f"Exists: {path}")

def cmd_run(args):
    # Minimal mock: "execute" by scanning for print(...) lines
    src = pathlib.Path(args.path).read_text(encoding="utf-8", errors="ignore")
    outs = []
    for line in src.splitlines():
        line = line.strip()
        if line.startswith("def main") and "print(" in src:
            # naive extract demo
            start = src.find('print(')
            end = src.find(')', start)
            if start != -1 and end != -1:
                payload = src[start+6:end]
                outs.append(payload.strip(' "'))
    if outs:
        for o in outs:
            print(o)
    else:
        print("(no output)")

def cmd_prove(args):
    # Mock obligations
    report = {
        "file": args.path,
        "obligations": 1,
        "proved": 1,
        "engine": "mock-smt",
        "ts": datetime.datetime.utcnow().isoformat() + "Z"
    }
    print(json.dumps(report, indent=2))

def cmd_zk(args):
    # Mock zk receipt
    payload = (pathlib.Path(args.path).read_text(encoding="utf-8", errors="ignore")).encode()
    digest = hashlib.sha256(payload).hexdigest()
    receipt = {
        "file": args.path,
        "zk_receipt": f"hgzk-{digest[:16]}",
        "note": "Mock receipt — real circuits in v1.6",
    }
    print(json.dumps(receipt, indent=2))

def cmd_pack(args):
    dist = pathlib.Path("dist")
    dist.mkdir(exist_ok=True)
    artifact = dist / "hg-artifact.hgz"
    with open(artifact, "wb") as f:
        f.write(b"# HyperGlottal artifact (mock)\n")
    sha = hashlib.sha256(artifact.read_bytes()).hexdigest()
    (dist / "hg-artifact.sha256").write_text(sha + "  " + artifact.name + "\n")
    print(f"Wrote {artifact} (+ SHA256)")

def make_parser():
    p = argparse.ArgumentParser(prog="hg", description=BANNER)
    sub = p.add_subparsers(dest="cmd", required=True)
    sp = sub.add_parser("version"); sp.set_defaults(func=cmd_version)
    sp = sub.add_parser("new"); sp.add_argument("path"); sp.set_defaults(func=cmd_new)
    sp = sub.add_parser("run"); sp.add_argument("path"); sp.set_defaults(func=cmd_run)
    sp = sub.add_parser("prove"); sp.add_argument("path"); sp.set_defaults(func=cmd_prove)
    sp = sub.add_parser("zk"); sp.add_argument("path"); sp.set_defaults(func=cmd_zk)
    sp = sub.add_parser("pack"); sp.set_defaults(func=cmd_pack)
    return p

def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    args = make_parser().parse_args(argv)
    args.func(args)

if __name__ == "__main__":
    main()
