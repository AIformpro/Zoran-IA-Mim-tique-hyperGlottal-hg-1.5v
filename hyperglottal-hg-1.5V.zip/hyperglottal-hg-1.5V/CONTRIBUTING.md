# Contributing

1. Fork, branch (`feat/...`), commit (conventional), PR.
2. Run tests: `pytest -q`.
3. Sign your commits if possible. Keep changes focused.
