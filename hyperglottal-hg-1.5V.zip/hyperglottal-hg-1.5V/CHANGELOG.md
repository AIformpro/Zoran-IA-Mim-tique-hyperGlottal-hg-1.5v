# Changelog

## v1.5 (“1.5V”) — 2025-08-12
- Première release publique du **subset M0** (ASCII‑only) : parser minimal, IR, checker symbolique mock, CLI `hg`.
- Dossier `schemas/` avec `module-0.1.json`.
- EBNF préliminaire `grammar/hg.ebnf`.
- Exemple `examples/hello.hg`.
