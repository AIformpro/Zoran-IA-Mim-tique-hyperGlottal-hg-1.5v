# Security Policy

Report vulnerabilities privately via security@institutia.dev.
Avoid publishing exploits before a fix is available.
