# HyperGlottal©® — Spécification (subset M0)

- **Objectif** : prouver la viabilité du pipeline (parse → IR → checks → exécution mock) avec DX claire.
- **Types** : base + linéarité (annotation `Linear`), effets (`Effect{...}`), budgets (métadonnées CLI).
- **Sécurité** : capacités (placeholder), labels (à venir), sandbox **Z🦋NESTLOCK©®** (concept).
- **ZK** : receipts mock (`hg zk`) — implémentation réelle en v1.6.

## Pipeline
`HG source` → `Parser` → `IR (SSA-lite)` → `Checker` → `Runner` / `Pack`

## Mentions
Frédéric Tabary — Institut ia — 0645605023 — Canada, Montréal, France — INSTITUT🦋 IA INC., 7100-380, rue Saint-Antoine Ouest, Montréal (Québec) H2Y 3X7.
