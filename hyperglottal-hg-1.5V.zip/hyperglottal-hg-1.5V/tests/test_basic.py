import importlib, pathlib, subprocess, sys

def test_version():
    cli = importlib.import_module("hyperglottal.cli")
    assert cli.VERSION.startswith("1.5")

def test_checker_balanced():
    from hyperglottal.checker import typecheck
    text = "def add(a:Int,b:Int)=a+b\ndef main()=print(\"ok\")\n"
    assert typecheck(text)
